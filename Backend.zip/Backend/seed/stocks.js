const mongoose = require("mongoose");
const dotenv = require("dotenv");

const connectDB = require("../config/db");
const Stock = require("../models/stock.model");

dotenv.config();

const stocks = [
  {
    symbol: "AAPL",
    companyName: "Apple Inc.",
    exchange: "NASDAQ",
    industry: "Technology",
    currentPrice: 308.91,
    previousClose: 306.40,
    logo: "",
  },
  {
    symbol: "MSFT",
    companyName: "Microsoft",
    exchange: "NASDAQ",
    industry: "Technology",
    currentPrice: 464.72,
    previousClose: 461.50,
    logo: "",
  },
  {
    symbol: "TSLA",
    companyName: "Tesla",
    exchange: "NASDAQ",
    industry: "Automobile",
    currentPrice: 311.21,
    previousClose: 309.80,
    logo: "",
  },
  {
    symbol: "NVDA",
    companyName: "NVIDIA",
    exchange: "NASDAQ",
    industry: "Semiconductor",
    currentPrice: 200.75,
    previousClose: 198.10,
    logo: "",
  },
  {
    symbol: "AMZN",
    companyName: "Amazon",
    exchange: "NASDAQ",
    industry: "E-Commerce",
    currentPrice: 271.58,
    previousClose: 269.95,
    logo: "",
  },
  {
    symbol: "GOOGL",
    companyName: "Alphabet Inc.",
    exchange: "NASDAQ",
    industry: "Technology",
    currentPrice: 356.13,
    previousClose: 353.20,
    logo: "",
  },
  {
    symbol: "META",
    companyName: "Meta",
    exchange: "NASDAQ",
    industry: "Technology",
    currentPrice: 712.25,
    previousClose: 706.80,
    logo: "",
  },
  {
    symbol: "NFLX",
    companyName: "Netflix",
    exchange: "NASDAQ",
    industry: "Entertainment",
    currentPrice: 1245.45,
    previousClose: 1238.90,
    logo: "",
  },
  {
    symbol: "TCS",
    companyName: "Tata Consultancy Services",
    exchange: "NSE",
    industry: "IT Services",
    currentPrice: 3520.75,
    previousClose: 3504.20,
    logo: "",
  },
  {
    symbol: "INFY",
    companyName: "Infosys",
    exchange: "NSE",
    industry: "IT Services",
    currentPrice: 1625.30,
    previousClose: 1618.15,
    logo: "",
  },
];

const seedDatabase = async () => {
  try {
    await connectDB();

    console.log("🌱 Seeding Stocks...");

    await Stock.deleteMany();

    await Stock.insertMany(stocks);

    console.log("✅ Stocks Seeded Successfully");

    mongoose.connection.close();
  } catch (error) {
    console.error("❌ Seeding Failed:", error.message);
    process.exit(1);
  }
};

seedDatabase();